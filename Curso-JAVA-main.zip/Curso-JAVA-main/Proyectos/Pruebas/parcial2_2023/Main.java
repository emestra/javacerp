package Proyectos.Pruebas.parcial2_2023;

//import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {

        // Impresión de Hola
        System.out.println("HolaM1");
/* 
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Juego juego = new Juego();
                VistaJuego vista = new VistaJuego();
                ControladorJuego controlador = new ControladorJuego(juego, vista);
                controlador.iniciarJuego();
            }
        });*/
    }
}

