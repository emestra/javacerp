var searchData=
[
  ['admincontrolador_0',['AdminControlador',['../classPreguntasDelCursoMVC_1_1AdminControlador.html',1,'PreguntasDelCursoMVC']]],
  ['admingui_1',['AdminGUI',['../classPreguntasDelCurso_1_1AdminGUI.html',1,'PreguntasDelCurso.AdminGUI'],['../classPreguntasDelCursoMVC_1_1AdminGUI.html',1,'PreguntasDelCursoMVC.AdminGUI']]]
];
