var searchData=
[
  ['pregunta_0',['Pregunta',['../classPreguntasDelCurso_1_1Pregunta.html#acdbf335937d6db92722d59b62e89f4c3',1,'PreguntasDelCurso::Pregunta']]],
  ['preguntagui_1',['PreguntaGUI',['../classPreguntasDelCurso_1_1PreguntaGUI.html#af7c6bed2d7ba230b6bfa54253d31f0b6',1,'PreguntasDelCurso.PreguntaGUI.PreguntaGUI()'],['../classPreguntasDelCursoMVC_1_1PreguntaGUI.html#ab2475802b3b6be7a0eb4a2106f9ad800',1,'PreguntasDelCursoMVC.PreguntaGUI.PreguntaGUI()']]],
  ['preguntaslist_2',['PreguntasList',['../classPreguntasDelCurso_1_1PreguntasList.html#a17b327893d6a1d9c364b7e2990e307a6',1,'PreguntasDelCurso::PreguntasList']]]
];
