var searchData=
[
  ['iniciogui_0',['InicioGUI',['../classPreguntasDelCurso_1_1InicioGUI.html',1,'PreguntasDelCurso.InicioGUI'],['../classPreguntasDelCursoMVC_1_1InicioGUI.html',1,'PreguntasDelCursoMVC.InicioGUI']]]
];
