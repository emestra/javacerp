var searchData=
[
  ['limpiararchivo_0',['limpiarArchivo',['../classPreguntasDelCurso_1_1FileHandler.html#a23c6cd5d9c0e86f7000721140ff5f364',1,'PreguntasDelCurso.FileHandler.limpiarArchivo()'],['../classPreguntasDelCursoMVC_1_1FileHandler.html#a18b80825bf5a79bb36b0a696c6affc3d',1,'PreguntasDelCursoMVC.FileHandler.limpiarArchivo()']]]
];
