var searchData=
[
  ['pregunta_0',['Pregunta',['../classPreguntasDelCurso_1_1Pregunta.html',1,'PreguntasDelCurso']]],
  ['preguntagui_1',['PreguntaGUI',['../classPreguntasDelCurso_1_1PreguntaGUI.html',1,'PreguntasDelCurso.PreguntaGUI'],['../classPreguntasDelCursoMVC_1_1PreguntaGUI.html',1,'PreguntasDelCursoMVC.PreguntaGUI']]],
  ['preguntaslist_2',['PreguntasList',['../classPreguntasDelCurso_1_1PreguntasList.html',1,'PreguntasDelCurso']]]
];
