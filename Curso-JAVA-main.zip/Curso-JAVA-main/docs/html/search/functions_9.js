var searchData=
[
  ['readquestions_0',['readQuestions',['../classPreguntasDelCurso_1_1FileHandler.html#a7fc8f657d95ea9dd424007d4319cf23c',1,'PreguntasDelCurso.FileHandler.readQuestions()'],['../classPreguntasDelCursoMVC_1_1FileHandler.html#a0dc7778d79fa304b6d3a1379dc321deb',1,'PreguntasDelCursoMVC.FileHandler.readQuestions()']]],
  ['removequestion_1',['removeQuestion',['../classPreguntasDelCurso_1_1PreguntasList.html#ab9d9934581157130f9a807db1e3bcb5c',1,'PreguntasDelCurso::PreguntasList']]]
];
