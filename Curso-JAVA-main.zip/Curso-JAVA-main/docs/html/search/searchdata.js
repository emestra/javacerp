var indexSectionsWithContent =
{
  0: "acefgilmprstw",
  1: "aefimpr",
  2: "p",
  3: "aefimprt",
  4: "acefgilmprsw",
  5: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Funciones",
  5: "Páginas"
};

