var searchData=
[
  ['setcorrecta_0',['setCorrecta',['../classPreguntasDelCurso_1_1Pregunta.html#a8021b9a2e40856d817b12916b76e5b8e',1,'PreguntasDelCurso::Pregunta']]],
  ['setcurrentquestionindex_1',['setCurrentQuestionIndex',['../classPreguntasDelCurso_1_1AdminGUI.html#a5bee8c31c79dbe4b8ec965cc58a08a6c',1,'PreguntasDelCurso.AdminGUI.setCurrentQuestionIndex()'],['../classPreguntasDelCursoMVC_1_1AdminGUI.html#af40d3ca23671dcfdd87cbfd9fa230bd3',1,'PreguntasDelCursoMVC.AdminGUI.setCurrentQuestionIndex()']]],
  ['setidpregunta_2',['setIdPregunta',['../classPreguntasDelCurso_1_1Pregunta.html#a3cfa754b13703b4ec7b971a1def5492d',1,'PreguntasDelCurso::Pregunta']]],
  ['setpregunta_3',['setPregunta',['../classPreguntasDelCurso_1_1Pregunta.html#a9553e2caf650b33e91ef3ea1cce19d37',1,'PreguntasDelCurso::Pregunta']]],
  ['setsalariomensual_4',['setSalarioMensual',['../classEmpleado.html#a3d258ab0b1e5bc7164a930196e5e84a3',1,'Empleado']]],
  ['size_5',['size',['../classPreguntasDelCurso_1_1PreguntasList.html#ad619f60924f1e8757e90ea928fde9d82',1,'PreguntasDelCurso::PreguntasList']]]
];
