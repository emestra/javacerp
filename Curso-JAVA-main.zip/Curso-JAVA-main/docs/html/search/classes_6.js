var searchData=
[
  ['randomizer_0',['Randomizer',['../classPreguntasDelCurso_1_1Randomizer.html',1,'PreguntasDelCurso']]]
];
