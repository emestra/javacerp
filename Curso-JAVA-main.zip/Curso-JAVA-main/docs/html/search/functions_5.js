var searchData=
[
  ['iniciogui_0',['InicioGUI',['../classPreguntasDelCurso_1_1InicioGUI.html#a7ddaa58b70fba39e7ee2369b31be795b',1,'PreguntasDelCurso.InicioGUI.InicioGUI()'],['../classPreguntasDelCursoMVC_1_1InicioGUI.html#a4fdc1469c26ffefb108352ee555f3208',1,'PreguntasDelCursoMVC.InicioGUI.InicioGUI()']]]
];
